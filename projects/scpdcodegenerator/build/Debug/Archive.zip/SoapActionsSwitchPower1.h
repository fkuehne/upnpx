//Auto Generated file.
//Copyright 2010 Bruno Keymolen, Arcanegra BVBA. All rights reserved.

#import <Foundation/Foundation.h>
#import "SoapAction.h"

@interface SoapActionsSwitchPower1 : SoapAction {
    }

//SOAP

-(int)SetTargetWithnewTargetValue:(NSString*)newtargetvalue;
-(int)GetTargetWithOutRetTargetValue:(NSMutableString*)rettargetvalue;
-(int)GetStatusWithOutResultStatus:(NSMutableString*)resultstatus;

@end
